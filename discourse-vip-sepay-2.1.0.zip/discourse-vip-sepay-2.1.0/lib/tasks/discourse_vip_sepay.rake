# frozen_string_literal: true
namespace :discourse_vip_sepay do
  desc "Expire VIP orders/subscriptions and clean old plugin data"
  task maintenance: :environment do
    DiscourseVipSepay::CleanupService.run!
    puts "VIP SePay maintenance completed."
  end

  desc "Permanently purge all data owned by Discourse VIP SePay"
  task purge: :environment do
    abort "Set CONFIRM=YES to purge Discourse VIP SePay data" unless ENV["CONFIRM"] == "YES"
    [VipSepayAuditLog, VipSepayTransaction, VipSepaySubscription, VipSepayOrder, VipSepayPlan].each { |klass| klass.delete_all }
    if ActiveRecord::Base.connection.data_source_exists?("site_settings")
      setting_names = %w[vip_sepay_enabled vip_sepay_bank_name vip_sepay_bank_bin vip_sepay_bank_template vip_sepay_account_number vip_sepay_account_holder vip_sepay_payment_prefix vip_sepay_webhook_secret vip_sepay_webhook_tolerance_seconds vip_sepay_order_expiry_minutes vip_sepay_extend_existing vip_sepay_replace_different_group vip_sepay_require_exact_amount vip_sepay_cleanup_paid_orders_days vip_sepay_cleanup_audit_days]
      SiteSetting.where(name: setting_names).delete_all
    end
    puts "Discourse VIP SePay data purged. Discourse users, posts, groups and categories were not deleted."
  end
end
