# Discourse VIP SePay — 2.1.0

Plugin VIP cho Discourse, lấy cảm hứng từ mô hình **Discourse Subscriptions**, nhưng thanh toán bằng chuyển khoản ngân hàng Việt Nam qua **SePay + VietQR**.

## 1. Mục tiêu

Plugin được thiết kế để nhiều diễn đàn Việt Nam có thể cài độc lập:

- Mỗi diễn đàn tự cấu hình ngân hàng, SePay Secret và các Group.
- Không hard-code domain `traiviet.net`.
- Gói VIP có thể gắn với bất kỳ Discourse Group nào.
- Group dùng chính cơ chế permission của Discourse để cấp quyền viết bài/category.
- Dữ liệu plugin nằm trong namespace/table riêng.
- Migration chỉ thêm mới, không sửa migration đã phát hành.
- Có purge riêng khi gỡ plugin.

## 2. Luồng thành viên

`/vip` → chọn gói → tạo đơn → VietQR → chuyển khoản → SePay webhook → xác minh HMAC → đối chiếu mã + tiền + tài khoản → khóa giao dịch → đánh dấu Paid → thêm Group → kích hoạt hạn VIP.

Khi hết hạn: job/maintenance xử lý subscription và chỉ gỡ Group nếu membership đó do plugin tạo.

## 3. Admin UI 2.1.0

Truy cập:

`/admin/plugins/discourse-vip-sepay`

Các khu vực:

- Tổng quan
  - Doanh thu tổng
  - Doanh thu hôm nay
  - Đơn chờ
  - VIP đang hoạt động
  - VIP sắp hết hạn
- Gói VIP
  - Tạo gói
  - Giá VND
  - Số ngày
  - Chọn Group
  - Bật/tắt bán
- Đơn hàng
  - Mã đơn
  - Thành viên
  - Gói
  - Số tiền
  - Trạng thái
  - Hủy đơn chờ
- Giao dịch SePay
  - ID SePay
  - Mã đơn
  - Số tiền
  - Gateway
  - Trạng thái
- Thành viên VIP
  - Group
  - Ngày bắt đầu
  - Ngày hết hạn
  - Hủy VIP

## 4. Cấu hình SePay

Site Settings:

- `vip_sepay_enabled`
- `vip_sepay_bank_name`
- `vip_sepay_bank_bin`
- `vip_sepay_bank_template`
- `vip_sepay_account_number`
- `vip_sepay_account_holder`
- `vip_sepay_payment_prefix`
- `vip_sepay_webhook_secret`
- `vip_sepay_webhook_tolerance_seconds`
- `vip_sepay_order_expiry_minutes`
- `vip_sepay_extend_existing`
- `vip_sepay_replace_different_group`
- `vip_sepay_require_exact_amount`

Webhook:

`POST https://TEN-MIEN/vip/sepay/webhook`

Production nên dùng HTTPS + HMAC-SHA256. SePay ký chuỗi `{timestamp}.{raw_body}` và gửi `X-SePay-Signature` cùng `X-SePay-Timestamp`; không được parse rồi serialize lại body trước khi kiểm tra chữ ký.

## 5. Cấu hình Group

Ví dụ:

- VIP 7 ngày → Group `vip-7`
- VIP 30 ngày → Group `vip-30`
- VIP 90 ngày → Group `vip-90`
- VIP 365 ngày → Group `vip-365`

Sau đó vào Category → Security và cấp `Create Topic` cho Group tương ứng.

## 6. Bảo mật

Plugin kiểm tra:

1. HMAC-SHA256.
2. Timestamp chống replay.
3. Transaction ID duy nhất.
4. Database lock khi áp dụng đơn.
5. Mã thanh toán.
6. Số tiền chính xác nếu bật `vip_sepay_require_exact_amount`.
7. Tài khoản nhận tiền nếu payload cung cấp `accountNumber`.
8. Đơn phải còn `pending` và chưa hết hạn.

Không lưu Secret SePay vào source code.

## 7. Gỡ plugin sạch

Không chỉ xóa thư mục plugin.

Chạy:

```bash
cd /var/discourse
./launcher enter app
RAILS_ENV=production CONFIRM=YES bundle exec rake discourse_vip_sepay:purge
exit
```

Sau đó xóa plugin khỏi `app.yml` và rebuild.

Purge chỉ xóa dữ liệu do plugin sở hữu; không xóa User, Topic, Post, Category hoặc Group của Discourse.

## 8. Nâng cấp

Không sửa migration đã phát hành.

Ví dụ:

```text
2.0.0
 ↓
2.1.0
 ↓
2.2.0
 ↓
3.0.0
```

Mỗi thay đổi database tạo migration timestamp mới.

## 9. Kiểm tra trước production

Trên môi trường test:

```bash
ruby -c plugin.rb
RAILS_ENV=test bundle exec rake db:migrate
RAILS_ENV=test bundle exec rspec plugins/discourse-vip-sepay/spec
```

Sau đó kiểm thử SePay Test Mode:

1. Tạo webhook test.
2. Chọn HMAC-SHA256.
3. Tạo một gói VIP test.
4. Tạo order.
5. Mô phỏng giao dịch đúng tiền + đúng mã.
6. Kiểm tra Group.
7. Gửi lại cùng transaction ID để kiểm tra duplicate.
8. Gửi sai signature.
9. Gửi timestamp quá cũ.
10. Chạy expiry.

## 10. Giới hạn của 2.1.0

`ReconciliationService` đã tạo khung để đối soát định kỳ, nhưng chưa tự gọi SePay Transactions API vì mỗi hệ thống có thể dùng API credential/scope khác nhau. Đây là phần nên hoàn thiện ở 2.2.0 cùng với:

- API credential mã hóa.
- Đồng bộ giao dịch bị mất webhook.
- CSV export.
- Bộ lọc ngày.
- Dashboard doanh thu theo ngày/tháng.
- Coupon/khuyến mãi.
- Gói dùng thử.
- Gói tự gia hạn nếu triển khai cơ chế thanh toán phù hợp.
- Email/notification khi VIP sắp hết hạn.
- Import/export cấu hình gói.
- Health check SePay.
