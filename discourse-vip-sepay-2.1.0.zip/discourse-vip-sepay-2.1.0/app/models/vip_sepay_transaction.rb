# frozen_string_literal: true
class VipSepayTransaction < ActiveRecord::Base
  self.table_name = "vip_sepay_transactions"
  validates :sepay_transaction_id, presence: true, uniqueness: true
  belongs_to :order, class_name: "VipSepayOrder", optional: true
  belongs_to :user, optional: true
end
