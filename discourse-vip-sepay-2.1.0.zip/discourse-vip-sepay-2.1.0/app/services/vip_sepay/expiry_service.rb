# frozen_string_literal: true
module DiscourseVipSepay
  class ExpiryService
    def self.expire_orders!
      VipSepayOrder.pending.where("expires_at <= ?", Time.current).find_each do |order|
        order.update!(status: "expired")
        VipSepayAuditLog.create!(user_id: order.user_id, action: "order_expired", resource_type: "VipSepayOrder", resource_id: order.id)
      end
    end
    def self.expire_subscriptions!
      VipSepaySubscription.where(status: "active").where("expires_at <= ?", Time.current).find_each { |s| MembershipService.expire!(s) }
    end
  end
end
