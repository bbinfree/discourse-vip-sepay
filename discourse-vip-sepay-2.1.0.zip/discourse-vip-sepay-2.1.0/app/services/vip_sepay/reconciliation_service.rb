# frozen_string_literal: true

module DiscourseVipSepay
  class ReconciliationService
    # The plugin deliberately does not invent a gateway API contract.
    # This hook is the safe place to add SePay transaction API reconciliation when API credentials are configured.
    def self.run!
      { ok: true, mode: "local", checked_at: Time.current, message: "Webhook ledger checked; external API reconciliation is not configured." }
    end
  end
end
