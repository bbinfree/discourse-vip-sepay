# frozen_string_literal: true
module DiscourseVipSepay
  class CleanupService
    def self.run!
      ExpiryService.expire_orders!
      ExpiryService.expire_subscriptions!
      order_cutoff = SiteSetting.vip_sepay_cleanup_paid_orders_days.to_i.days.ago
      VipSepayOrder.where(status: %w[paid cancelled expired]).where("updated_at < ?", order_cutoff).delete_all
      VipSepayTransaction.where("created_at < ?", order_cutoff).delete_all
      VipSepayAuditLog.where("created_at < ?", SiteSetting.vip_sepay_cleanup_audit_days.to_i.days.ago).delete_all
    end
  end
end
