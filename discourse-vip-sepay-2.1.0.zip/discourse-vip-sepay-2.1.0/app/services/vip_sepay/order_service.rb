# frozen_string_literal: true
require "securerandom"
module DiscourseVipSepay
  class OrderService
    def self.create!(user:, plan:)
      raise I18n.t("discourse_vip_sepay.errors.invalid_plan") unless plan&.active?
      existing = VipSepayOrder.pending.where(user_id: user.id).where("expires_at > ?", Time.current).order(id: :desc).first
      return existing if existing
      prefix = SiteSetting.vip_sepay_payment_prefix.to_s.upcase.gsub(/[^A-Z0-9]/, "").first(12)
      code = nil
      10.times do
        candidate = "#{prefix.presence || 'VIP'}#{Time.current.strftime('%y%m%d')}#{SecureRandom.hex(3).upcase}"
        unless VipSepayOrder.exists?(order_code: candidate)
          code = candidate
          break
        end
      end
      raise "Unable to allocate unique payment code" unless code
      order = VipSepayOrder.create!(order_code: code, user_id: user.id, plan_id: plan.id, amount_vnd: plan.price_vnd, status: "pending", expires_at: SiteSetting.vip_sepay_order_expiry_minutes.to_i.minutes.from_now)
      VipSepayAuditLog.create!(user_id: user.id, action: "order_created", resource_type: "VipSepayOrder", resource_id: order.id, details: { plan_id: plan.id }.to_json)
      Jobs.enqueue_at(order.expires_at, :vip_sepay_expire_order, order_id: order.id)
      order
    end
  end
end
