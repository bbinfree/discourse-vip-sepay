# frozen_string_literal: true
require "openssl"
require "uri"
module DiscourseVipSepay
  class PaymentService
    def self.verify_hmac!(raw_body, signature, timestamp)
      secret = SiteSetting.vip_sepay_webhook_secret.to_s
      return false if secret.blank? || signature.blank? || timestamp.blank?
      ts = Integer(timestamp) rescue nil
      return false unless ts && (Time.now.to_i - ts).abs <= SiteSetting.vip_sepay_webhook_tolerance_seconds.to_i
      expected = OpenSSL::HMAC.hexdigest("SHA256", secret, "#{timestamp}.#{raw_body}")
      Rack::Utils.secure_compare(expected, signature.to_s.sub(/\Asha256=/i, ""))
    end
    def self.apply!(payload)
      tx_id = payload["id"].to_s.presence
      raise "missing transaction id" if tx_id.blank?
      return :duplicate if VipSepayTransaction.exists?(sepay_transaction_id: tx_id)
      amount = payload["transferAmount"].to_i
      type = payload["transferType"].to_s.downcase
      code = payload["code"].to_s.presence
      content = payload["content"].to_s
      order_code = code || content[/\b[A-Z0-9]{5,30}\b/i]
      order = VipSepayOrder.find_by(order_code: order_code)
      tx = VipSepayTransaction.create!(sepay_transaction_id: tx_id, order_code: order_code, order_id: order&.id, user_id: order&.user_id, amount_vnd: amount, transfer_type: type, gateway: payload["gateway"].to_s, reference_code: payload["referenceCode"].to_s.presence, transaction_at: parse_time(payload["transactionDate"]), content: content, raw_payload: payload.to_json, status: "received", account_number: payload["accountNumber"].to_s.presence, counterparty_account: payload["counterAccountNumber"].to_s.presence)
      return :ignored unless order && type.in?(["", "in"])
      return :ignored unless code == order.order_code || content.match?(/\b#{Regexp.escape(order.order_code)}\b/i)
      return :ignored if SiteSetting.vip_sepay_require_exact_amount && amount != order.amount_vnd
      destination = payload["accountNumber"].to_s.presence
      configured = SiteSetting.vip_sepay_account_number.to_s.presence
      return :ignored if configured.present? && destination.present? && destination != configured
      return :ignored unless order.status == "pending" && order.expires_at > Time.current
      ActiveRecord::Base.transaction do
        order.lock!
        return :duplicate if order.paid?
        order.update!(status: "paid", paid_at: Time.current, sepay_transaction_id: tx_id, reference_code: tx.reference_code, raw_payload: payload.to_json)
        MembershipService.activate!(order: order)
        tx.update!(status: "applied")
        VipSepayAuditLog.create!(user_id: order.user_id, action: "payment_applied", resource_type: "VipSepayOrder", resource_id: order.id, details: { transaction_id: tx_id }.to_json)
      end
      :paid
    rescue ActiveRecord::RecordNotUnique
      :duplicate
    end
    def self.qr_url(order)
      query = { acc: SiteSetting.vip_sepay_account_number, bank: SiteSetting.vip_sepay_bank_bin.presence || SiteSetting.vip_sepay_bank_name, amount: order.amount_vnd, des: order.order_code, template: SiteSetting.vip_sepay_bank_template.presence || "compact2" }
      "https://vietqr.app/img?#{URI.encode_www_form(query.reject { |_k, v| v.blank? })}"
    end
    def self.parse_time(value)
      Time.zone.parse(value.to_s) rescue nil
    end
  end
end
