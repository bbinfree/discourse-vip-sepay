# frozen_string_literal: true
class Jobs::VipSepayExpireSubscription < Jobs::Base
  def execute(args)
    subscription = VipSepaySubscription.find_by(id: args[:subscription_id])
    return unless subscription
    DiscourseVipSepay::MembershipService.expire!(subscription) if subscription.expires_at <= Time.current
  end
end
