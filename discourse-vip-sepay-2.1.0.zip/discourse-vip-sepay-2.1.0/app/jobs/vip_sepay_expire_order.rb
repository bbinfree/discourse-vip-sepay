# frozen_string_literal: true
class Jobs::VipSepayExpireOrder < Jobs::Base
  def execute(args)
    order = VipSepayOrder.find_by(id: args[:order_id])
    return unless order
    DiscourseVipSepay::ExpiryService.expire_orders!
  end
end
