# frozen_string_literal: true
require "rails_helper"

describe DiscourseVipSepay::PaymentService do
  describe ".verify_hmac!" do
    it "accepts a valid signature and timestamp" do
      raw = '{"id":1}'
      timestamp = Time.now.to_i.to_s
      secret = "secret"
      SiteSetting.vip_sepay_webhook_secret = secret
      signature = "sha256=" + OpenSSL::HMAC.hexdigest("SHA256", secret, "#{timestamp}.#{raw}")
      expect(described_class.verify_hmac!(raw, signature, timestamp)).to eq(true)
    end

    it "rejects a stale timestamp" do
      SiteSetting.vip_sepay_webhook_secret = "secret"
      timestamp = (Time.now.to_i - 100_000).to_s
      signature = "sha256=" + OpenSSL::HMAC.hexdigest("SHA256", "secret", "#{timestamp}.body")
      expect(described_class.verify_hmac!("body", signature, timestamp)).to eq(false)
    end
  end
end
