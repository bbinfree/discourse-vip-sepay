# frozen_string_literal: true

Discourse::Application.routes.draw do
  get "/vip" => "discourse_vip_sepay#index"
  get "/vip/checkout/:order_code" => "discourse_vip_sepay#checkout"
  post "/vip/orders" => "discourse_vip_sepay#create_order"
  get "/vip/orders/:order_code/status" => "discourse_vip_sepay#status"
  post "/vip/sepay/webhook" => "discourse_vip_sepay#webhook"

  namespace :admin do
    get "/plugins/vip-sepay" => "vip_sepay#index"
    get "/plugins/vip-sepay/plans.json" => "vip_sepay#plans"
    post "/plugins/vip-sepay/plans.json" => "vip_sepay#create_plan"
    put "/plugins/vip-sepay/plans/:id.json" => "vip_sepay#update_plan"
    delete "/plugins/vip-sepay/plans/:id.json" => "vip_sepay#destroy_plan"
    get "/plugins/vip-sepay/orders.json" => "vip_sepay#orders"
    get "/plugins/vip-sepay/transactions.json" => "vip_sepay#transactions"
    get "/plugins/vip-sepay/subscriptions.json" => "vip_sepay#subscriptions"
    post "/plugins/vip-sepay/subscriptions/:id/cancel.json" => "vip_sepay#cancel_subscription"
    post "/plugins/vip-sepay/maintenance.json" => "vip_sepay#maintenance"
  end
end
