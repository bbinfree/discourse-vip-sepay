# frozen_string_literal: true

# name: discourse-vip-sepay
# about: VIP memberships for Discourse using Vietnamese bank-transfer payments through SePay/VietQR.
# version: 2.1.0
# authors: OpenAI
# url: https://github.com/discourse/discourse-plugin-skeleton
# required_version: 2026.1.0

enabled_site_setting :vip_sepay_enabled
add_admin_route "discourse_vip_sepay.admin.title", "discourse-vip-sepay", use_new_show_route: true

register_asset "stylesheets/vip-sepay.scss"
register_asset "javascripts/discourse/vip-sepay.js"
register_asset "javascripts/discourse/admin/admin-discourse-vip-sepay-route-map.js"
register_asset "javascripts/initializers/admin-vip-sepay-nav.js"

module ::DiscourseVipSepay
  PLUGIN_NAME = "discourse-vip-sepay"
  VERSION = "2.1.0"
end

Discourse::Application.routes.append do
  get "/vip" => "discourse_vip_sepay#index"
  get "/vip/checkout/:order_code" => "discourse_vip_sepay#checkout"
  post "/vip/orders" => "discourse_vip_sepay#create_order"
  get "/vip/orders/:order_code/status" => "discourse_vip_sepay#status"
  post "/vip/sepay/webhook" => "discourse_vip_sepay#webhook"

  get "/admin/plugins/discourse-vip-sepay" => "admin/plugins#index", constraints: StaffConstraint.new
  get "/admin/plugins/discourse-vip-sepay/*path" => "admin/plugins#index", constraints: StaffConstraint.new

  namespace :admin, constraints: StaffConstraint.new do
    get "/vip-sepay.json" => "vip_sepay#index"
    get "/vip-sepay/plans.json" => "vip_sepay#plans"
    get "/vip-sepay/groups.json" => "vip_sepay#groups"
    post "/vip-sepay/plans.json" => "vip_sepay#create_plan"
    put "/vip-sepay/plans/:id.json" => "vip_sepay#update_plan"
    delete "/vip-sepay/plans/:id.json" => "vip_sepay#destroy_plan"
    get "/vip-sepay/orders.json" => "vip_sepay#orders"
    get "/vip-sepay/transactions.json" => "vip_sepay#transactions"
    get "/vip-sepay/subscriptions.json" => "vip_sepay#subscriptions"
    get "/vip-sepay/members.json" => "vip_sepay#members"
    post "/vip-sepay/orders/:id/cancel.json" => "vip_sepay#cancel_order"
    post "/vip-sepay/subscriptions/:id/cancel.json" => "vip_sepay#cancel_subscription"
    post "/vip-sepay/subscriptions/:id/extend.json" => "vip_sepay#extend_subscription"
    post "/vip-sepay/maintenance.json" => "vip_sepay#maintenance"
    post "/vip-sepay/reconcile.json" => "vip_sepay#reconcile"
  end
end

after_initialize do
  %w[
    app/models/vip_sepay_plan.rb
    app/models/vip_sepay_order.rb
    app/models/vip_sepay_subscription.rb
    app/models/vip_sepay_transaction.rb
    app/models/vip_sepay_audit_log.rb
    app/services/vip_sepay/order_service.rb
    app/services/vip_sepay/payment_service.rb
    app/services/vip_sepay/membership_service.rb
    app/services/vip_sepay/expiry_service.rb
    app/services/vip_sepay/cleanup_service.rb
    app/services/vip_sepay/admin_dashboard_service.rb
    app/services/vip_sepay/reconciliation_service.rb
    app/controllers/discourse_vip_sepay_controller.rb
    app/controllers/admin/vip_sepay_controller.rb
  ].each { |file| require_relative file }
end
